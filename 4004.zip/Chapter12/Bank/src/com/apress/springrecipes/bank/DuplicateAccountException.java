package com.apress.springrecipes.bank;

public class DuplicateAccountException extends RuntimeException {

}
