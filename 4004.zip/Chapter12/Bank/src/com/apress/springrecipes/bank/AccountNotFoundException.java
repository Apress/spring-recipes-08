package com.apress.springrecipes.bank;

public class AccountNotFoundException extends RuntimeException {

}
