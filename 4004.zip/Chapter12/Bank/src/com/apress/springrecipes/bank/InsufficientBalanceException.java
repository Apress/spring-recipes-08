package com.apress.springrecipes.bank;

public class InsufficientBalanceException extends RuntimeException {

}
