package com.apress.springrecipes.shop;

public interface StorageConfig {

    public String getPath();
}
