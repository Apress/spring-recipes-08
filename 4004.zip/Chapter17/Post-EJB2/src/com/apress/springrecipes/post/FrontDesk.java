package com.apress.springrecipes.post;

public interface FrontDesk {

    public double calculatePostage(String country, double weight);
}
