package com.apress.springrecipes.post;

public interface FrontDesk {

    public void sendMail(Mail mail);
}
