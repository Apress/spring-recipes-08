package com.apress.springrecipes.post;

public interface BackOffice {

    public Mail receiveMail();
}
