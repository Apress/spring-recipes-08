package com.apress.springrecipes.library.service;

import java.util.Date;
import java.util.List;

public interface LibraryService {

    public List<Date> getHolidays();
}
