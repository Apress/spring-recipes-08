package com.apress.springrecipes.city;

public interface CityService {

    public double findDistance(String srcCity, String destCity);
}
