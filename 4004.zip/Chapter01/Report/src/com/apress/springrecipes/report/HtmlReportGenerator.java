package com.apress.springrecipes.report;

public class HtmlReportGenerator implements ReportGenerator {

    public void generate(String[][] table) {
        System.out.println("Generating HTML report ...");
    }
}
