package com.apress.springrecipes.report;

public interface ReportGenerator {

    public void generate(String[][] table);
}
