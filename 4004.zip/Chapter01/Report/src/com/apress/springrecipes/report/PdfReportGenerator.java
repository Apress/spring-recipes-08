package com.apress.springrecipes.report;

public class PdfReportGenerator implements ReportGenerator {

    public void generate(String[][] table) {
        System.out.println("Generating PDF report ...");
    }
}
