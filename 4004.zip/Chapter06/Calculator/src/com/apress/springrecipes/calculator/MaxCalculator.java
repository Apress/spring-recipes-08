package com.apress.springrecipes.calculator;

public interface MaxCalculator {

    public double max(double a, double b);
}
