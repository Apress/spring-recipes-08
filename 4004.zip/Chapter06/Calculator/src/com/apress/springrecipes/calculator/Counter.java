package com.apress.springrecipes.calculator;

public interface Counter {

    public void increase();
    public int getCount();
}
